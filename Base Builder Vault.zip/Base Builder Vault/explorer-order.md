This note is maintained by the Explorer Order Editor plugin. It stores the manual sort order for folders in this vault; the block below is machine-generated.

```json
{
  "/": ["General.md","Demo Scope.md","Art Bible.md","World.md","Progression.md","Build Mode.md","Spaceship.md","Inventory.md","Tech Tree","Resources","Drafts","Buildings","Bots","Recipes","open.url","Bot Upgrades","images","Docs.md"],
  "Bot Upgrades": ["Info.md","Miner Bot Upgrade.md","Worker bot Upgrade.md","Builder Bot Upgrade.md"],
  "Buildings/Machines": ["Press.md","Assembler.md","Furnace mk1.md","Electric Workbench.md","Alloy Furnace.md","Furnace mk2.md","Advanced Assembler.md","Advanced Press.md","Machines.md","Advanced Electric Workbench.md","Furnace mk3.md","Industrial Assembler.md","Industrial Electric Workbench.md"],
  "Buildings/Power System": ["Electric Poles.md","Power Pole.md","Generator mk1.md"],
  "Recipes": ["First Era recipe","Recipes.md","Second Era recipe","Third Era","other Eras"],
  "Recipes/First Era recipe/Metal/Foundry": ["Smelt to Iron 1.md","Smelt to Tin.md","Alloy smelting to Bronze.md","Smelt to Copper.md"],
  "Recipes/First Era recipe/Metal/Metalworking": ["Assemble to Bronze Casing.md"],
  "Recipes/Second Era recipe/Electrical Working": ["Advanced Electrify to Advanced Bot Frame.md","Advanced Electrify to Advanced circuit board.md","Advanced Electrify to Control Unit.md","Advanced Electrify to Electromagnet.md","Advanced Electrify to Gold Wire.md","Advanced Electrify to Electronic Module.md","Electrify to Copper Coil.md"],
  "Recipes/Third Era/Electrical Working": ["Industrial Electrify to Industrial Circuit Board.md","Industrial Electrify to Industrial Control Unit.md","Industrial Electrify to High Capacity Coil.md","Industrial Electrify to Power Regulator.md"],
  "Recipes/Third Era/Metal/Foundry": ["Smelt to Iron 3.md","Smelt to Titanium.md"],
  "Recipes/Third Era/Metal/Metalworking": ["Industrial Assemble to Titanium Casing.md","Industrial Assemble to Titanium Gear.md","Industrial Assemble to Titanium Rod.md","Industrial Press to Titanium Plate.md"],
  "Recipes/other Eras": ["Assemble into Ship Core Component.md","Assemble to Navigation Component.md","Assemble to Titanium Frame.md","Press to Titanium Plate.md"],
  "Resources": ["Resources.md","Raw","Ingots","Alloys","Crafted Items"],
  "Resources/Crafted Items": ["First Era","Crafted Items.md","Second Era","Third Era","other Eras"],
  "Resources/Crafted Items/First Era": ["Stone Brick.md","Insulator.md","Iron Plate.md","Circuit Board.md","Bronze Plate.md","Copper Wire.md","Copper Plate.md","Bronze Gear.md","Bronze Rod.md","Iron Casing.md","Iron Rod.md","Iron Gear.md","Machine Frame.md","Bronze Casing.md","Advanced Frame.md","Electric core.md","Reinforced Plate.md","Electric Components.md"],
  "Resources/Crafted Items/Second Era": ["Advanced Circuit Board.md","Advanced Machine Component.md","Advanced Machine Frame.md","Aluminum Casing.md","Aluminum Gear.md","Aluminum Plate.md","Aluminum Rod.md","Control Unit.md","Copper Coil.md","Electromagnet.md","Electronic Module.md","Gear Assemblies.md","Gold Wire.md","Heat Resistant Component.md","Nickel Plate.md","Nickel Rod.md","Gearbox.md","Precision Gear.md","Steel Casing.md","Steel Gear.md","Steel Plate.md","Steel Reinforced Plate.md","Steel Rod.md","Advanced Bot Frame.md"],
  "Resources/Crafted Items/Third Era": ["Industrial Machine Frame.md","Titanium Casing.md","Titanium Gear.md","Titanium Plate.md","Industrial Circuit Board.md","Industrial Control Unit.md","Titanium Rod.md","High Capacity Coil.md","Power Regulator.md"],
  "Resources/Crafted Items/other Eras": ["Navigation Component.md","Ship Core Component.md"],
  "Resources/Ingots": ["Aluminum.md","Copper.md","Gold.md","Iron.md","Tin.md","Nickel.md","Titanium.md","Ingots.md"],
  "Resources/Raw": ["Bauxite.md","Coal.md","Gold Ore.md","Hematite.md","Ilmenite.md","Pentladite.md","Magnetite.md","Malachite.md","Pyrite.md"]
}
```
