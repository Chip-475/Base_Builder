1 [[Advanced Circuit Board]] + 1 [[Advanced Electrify to Gold Wire]] + 2 [[Electric core]]

output:
1 [[Control Unit]]